/* Allegro datafile object indexes, produced by grabber v4.0.3 (RC2), MSVC */
/* Datafile: c:\Projecten\CS2D\hud.dat */
/* Date: Mon Jul 19 16:09:15 2004 */
/* Do not hand edit! */

#define HUD_CLOCK                        0        /* BMP  */
#define HUD_DBLDOT                       1        /* BMP  */
#define HUD_NUMBERS                      2        /* BMP  */

