// HUD functions
void HUD_DrawID(int id, int x, int y, int iAlpha);
void HUD_DrawNumber(char msg[10], int x, int y);
void HUD_DrawStatus(int iID);
void HUD_DrawSlots(int iID);
void HUD_DrawPlayer(int iID);
void HUD_Draw();
